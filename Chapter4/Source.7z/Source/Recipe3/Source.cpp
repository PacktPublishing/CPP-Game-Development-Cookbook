#include <iostream>
#include <conio.h>

using namespace std;

void Cubic_Order()
{
	int n = 100;
	for (int i = 0; i < n; i++)
	{
		for (int j=0; j < n; j++)
		{
			for (int k = 0; k < n; k++)
			{
				//Some implementation
			}
		}
	}
}
void Sqaure_Order()
{
	int n = 100;
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			//Some implementation
		}
	}
}

int main()
{
	Cubic_Order();
	Sqaure_Order();
	
	return 0;
}